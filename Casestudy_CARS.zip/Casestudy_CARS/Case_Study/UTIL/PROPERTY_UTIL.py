class propertyUtil:

    @staticmethod
    def getPropertyString():
        connection_string = (
            host:= "localhost",
                database:= "crime_reporting_system",
            user:= "root",
            password:= "jay@23"
        )

        return connection_string
    print("run successfully")